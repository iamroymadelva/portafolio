/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.CajaModel;
import Model.VentaModel;
import Params.Ventas;
import Params.Caja;
import View.Content_Caja;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author carlos_sanchez
 */
public class CajaController implements ActionListener{
    
    private final Content_Caja contentCaja;
    private final CajaModel cajaModel;
    private final Caja caja;
    
    private final VentaModel ventaModel;
    private final Ventas venta;
    
    public CajaController(Content_Caja content_Caja, CajaModel cajaModel){
        this.contentCaja = content_Caja;
        this.cajaModel = cajaModel;
        
        ventaModel = new VentaModel();
        venta = new Ventas();
        caja = new Caja();
        
        contentCaja.Caja_Buscar_Button.addActionListener(this);
        
        setDataCajaModelTable();
        setValueCaja();
    }
    
    private void setDataCajaModelTable(){
        ArrayList<Ventas> arrayVenta = ventaModel.getAllDataVenta();
        int total = 0;
        String[] columna = {"ID","PRODUCTO","VALOR","CANTIDAD","FECHA","DESCRIPCION","EMPLEADO","CLIENTE"};
        DefaultTableModel tableModel = new DefaultTableModel(columna,0);
        for (int i = 0; i < arrayVenta.size(); i++) {
            tableModel.addRow(new Object[] {arrayVenta.get(i).getId(),arrayVenta.get(i).getOtherProducto(),arrayVenta.get(i).getValor(),arrayVenta.get(i).getCantidad(),arrayVenta.get(i).getFecha(),arrayVenta.get(i).getDescripcion(),arrayVenta.get(i).getOtherEmpleado(),arrayVenta.get(i).getOtherCliente()});
            total += (arrayVenta.get(i).getValor() * arrayVenta.get(i).getCantidad());
        }
        contentCaja.Caja_Venta_List.setModel(tableModel);
        contentCaja.Caja_Ventas.setText(formatMoney(String.valueOf(total)));
    }
    
    public String formatMoney(String valor){
        DecimalFormat decimalFormat = new DecimalFormat("#,###");
        return String.valueOf(decimalFormat.format(Integer.parseInt(valor.replace(".",""))));
    }
    
    private void setValueCaja(){
        if(cajaModel.getAllDataCaja(caja)){
            contentCaja.Caja_Id.setText(String.valueOf(caja.getId()));
            contentCaja.Caja_Capital.setText(formatMoney(String.valueOf(caja.getCapital())));
        }
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == contentCaja.Caja_Buscar_Button){
            setDataFilterTable();
        }
    }
    
    public void setDataFilterTable(){
        venta.setFecha(contentCaja.Caja_Buscar.getText());
        ArrayList<Ventas> arrayVenta = ventaModel.getAllDataKey(venta);
        int total = 0;
        String[] columna = {"ID","PRODUCTO","VALOR","CANTIDAD","FECHA","DESCRIPCION","EMPLEADO","CLIENTE"};
        DefaultTableModel tableModel = new DefaultTableModel(columna,0);
        for (int i = 0; i < arrayVenta.size(); i++) {
            tableModel.addRow(new Object[] {arrayVenta.get(i).getId(),arrayVenta.get(i).getOtherProducto(),arrayVenta.get(i).getValor(),arrayVenta.get(i).getCantidad(),arrayVenta.get(i).getFecha(),arrayVenta.get(i).getDescripcion(),arrayVenta.get(i).getOtherEmpleado(),arrayVenta.get(i).getOtherCliente()});
            total += (arrayVenta.get(i).getValor() * arrayVenta.get(i).getCantidad());
        }
        contentCaja.Caja_Venta_List.setModel(tableModel);
        contentCaja.Caja_Ventas.setText(formatMoney(String.valueOf(total)));
    }
}
