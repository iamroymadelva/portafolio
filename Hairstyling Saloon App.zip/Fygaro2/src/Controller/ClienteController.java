/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.ClienteModel;
import View.Content_Cliente;
import Params.Cliente;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author carlos_sanchez
 */
public class ClienteController implements ActionListener{
    private final Content_Cliente contentCliente;
    private final Cliente cliente;
    private final ClienteModel clienteModel;
    
    public ClienteController(Content_Cliente contentCliente, ClienteModel clienteModel){
        this.contentCliente = contentCliente;
        this.clienteModel = clienteModel;
        
        cliente = new Cliente();
        
        contentCliente.Cliente_Buscar.addActionListener(this);
        contentCliente.Cliente_Generar.addActionListener(this);
        contentCliente.Cliente_Guardar.addActionListener(this);
        contentCliente.Cliente_Modificar.addActionListener(this);
        contentCliente.Cliente_Eliminar.addActionListener(this);
        contentCliente.Cliente_Borrar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == contentCliente.Cliente_Generar){
            EnabledButton();
            contentCliente.Cliente_Codigo.setText(GeneratorKeys() + "");
            contentCliente.Cliente_Guardar.setEnabled(true);
        }
        if(e.getSource() == contentCliente.Cliente_Buscar){
            if(verifyCodigo(contentCliente.Cliente_Codigo.getText())){
                if(clienteModel.getDataClienteKey(getDataCliente())){
                    EnabledButton();
                    setDataCliente();
                    contentCliente.Cliente_Modificar.setEnabled(true);
                    contentCliente.Cliente_Eliminar.setEnabled(true);
                }else
                    MessageError("No hay datos realcionados");
            }
        }
        if(e.getSource() == contentCliente.Cliente_Guardar){
            if(verifyDataCliente()){
                if(clienteModel.setDataCliente(getDataCliente()) == 1){
                    EnabledButton();
                    EnabledDefault();
                    resetDataCliente();
                    MessageSuccess("Guardado correctamente!!");
                }else
                    MessageError("Ah ocurrido algo inesperado, intentemoslo de nuevo.");
            }
        }
        if(e.getSource() == contentCliente.Cliente_Modificar){
            if(verifyDataCliente()){
                if(clienteModel.setUpdateDataCliente(getDataCliente()) == 1){
                    EnabledButton();
                    EnabledDefault();
                    resetDataCliente();
                    MessageSuccess("Modificado correctamente!!");
                }else
                    MessageError("Ah ocurrido algo inesperado, intentemoslo de nuevo.");
            }
        }
        if(e.getSource() == contentCliente.Cliente_Eliminar){
            if(verifyCodigo(contentCliente.Cliente_Codigo.getText())){
                if(clienteModel.setDeleteDataCliente(getDataCliente()) == 1){
                    EnabledButton();
                    EnabledDefault();
                    resetDataCliente();
                    MessageSuccess("Eliminado correctamente!!");
                }else
                    MessageError("Ah ocurrido algo inesperado, intentemoslo de nuevo.");
            }
        }
        if(e.getSource() == contentCliente.Cliente_Borrar){
            EnabledButton();
            EnabledDefault();
            resetDataCliente();
        }
    }
    
    public void EnabledButton(){
        contentCliente.Cliente_Codigo.setEnabled(false);
        contentCliente.Cliente_Guardar.setEnabled(false);
        contentCliente.Cliente_Buscar.setEnabled(false);
        contentCliente.Cliente_Eliminar.setEnabled(false);
        contentCliente.Cliente_Modificar.setEnabled(false);
        contentCliente.Cliente_Generar.setEnabled(false);
    }
    
    public void EnabledDefault(){
        contentCliente.Cliente_Generar.setEnabled(true);
        contentCliente.Cliente_Codigo.setEnabled(true);
        contentCliente.Cliente_Buscar.setEnabled(true);
    }
    
    public void resetDataCliente(){
        contentCliente.Cliente_Nombre.setText(null);
        contentCliente.Cliente_Apellido.setText(null);
        contentCliente.Cliente_Celular.setText(null);
        contentCliente.Cliente_Telefono.setText(null);
        contentCliente.Cliente_Correo.setText(null);
        contentCliente.Cliente_Codigo.setText(null);
    }
    
    public Cliente getDataCliente(){
        cliente.setNombre(contentCliente.Cliente_Nombre.getText().toUpperCase());
        cliente.setApellido(contentCliente.Cliente_Apellido.getText().toUpperCase());
        cliente.setCelular(contentCliente.Cliente_Celular.getText());
        cliente.setTelefono(contentCliente.Cliente_Telefono.getText());
        cliente.setCorreo(contentCliente.Cliente_Correo.getText());
        cliente.setId(Integer.parseInt(contentCliente.Cliente_Codigo.getText()));
        cliente.setFecha(contentCliente.Cliente_Fecha_Day.getSelectedItem().toString()+"/"+contentCliente.Cliente_Fecha_Month.getSelectedItem().toString()+"/"+contentCliente.Cliente_Fecha_Years.getSelectedItem().toString());
        cliente.setGenero(contentCliente.Cliente_Genero.getSelectedItem().toString());
        return cliente;
    }
    
    public void setDataCliente(){
        contentCliente.Cliente_Nombre.setText(cliente.getNombre());
        contentCliente.Cliente_Apellido.setText(cliente.getApellido());
        contentCliente.Cliente_Telefono.setText(cliente.getTelefono());
        contentCliente.Cliente_Celular.setText(cliente.getCelular());
        contentCliente.Cliente_Correo.setText(cliente.getCorreo());
        contentCliente.Cliente_Genero.setSelectedItem(cliente.getGenero());
        contentCliente.Cliente_Fecha_Day.setSelectedItem(cliente.getFecha().split("/")[0]);
        contentCliente.Cliente_Fecha_Month.setSelectedItem(cliente.getFecha().split("/")[1]);
        contentCliente.Cliente_Fecha_Years.setSelectedItem(cliente.getFecha().split("/")[2]);
    }
    
    public boolean verifyDataCliente(){
        if(contentCliente.Cliente_Nombre.getText().equals("")){
            MessageError("Campo nombre vacio");
            return false;
        }else if(contentCliente.Cliente_Apellido.getText().equals("")){
            MessageError("Campo apellido vacio");
            return false;
        }else if(contentCliente.Cliente_Celular.getText().equals("") || contentCliente.Cliente_Celular.getText().length() > 10 && contentCliente.Cliente_Celular.getText().length() < 10){
            MessageError("Numero de celular incorrecto");
            return false;
        }else if(!contentCliente.Cliente_Telefono.getText().equals("") && contentCliente.Cliente_Telefono.getText().length() < 7 && contentCliente.Cliente_Telefono.getText().length() > 8){
            MessageError("Numero de telefono incorrecto");
            return false;
        }else if(contentCliente.Cliente_Correo.getText().equals("") || !verifyEmail(contentCliente.Cliente_Correo.getText())){
            MessageError("Campo correo vacio o correo invalido");
            return false;
        }
        return true;
    }
    
    public void MessageError(String message){
        JOptionPane.showMessageDialog(null, message, null,JOptionPane.ERROR_MESSAGE);
    }
    
    public void MessageSuccess(String message){
        JOptionPane.showMessageDialog(null, message);
    }
    
    public boolean verifyEmail(String email){
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher mather = pattern.matcher(email);
        return mather.find();
    }
    
    public int GeneratorKeys(){
        ArrayList<Integer> key = new ArrayList<>(99999);
        for(int i = 40000; i < 59999; i++){
            key.add(i);
        }
        Random random = new Random();
        int number = 0;
        boolean sw = true;
        while(sw){
            if(key.size() > 0){
                number = random.nextInt(key.size());
                key.remove(number);
                cliente.setId(number);
                if(!clienteModel.getDataClienteKey(cliente))
                    sw = false;
            }
        }
        return number;
    }
    
    public boolean verifyCodigo(String value){
        return value.length() > 0;
    }
}
