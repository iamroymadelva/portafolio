/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.CajaModel;
import Model.ConfiguracionModel;
import Params.Caja;
import View.Content_Configuracion;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author carlos_sanchez
 */
public class ConfiguracionController implements ActionListener{

    private final Content_Configuracion contentConfiguracion;
    private final int Nivel;
    private final ConfiguracionModel configuracionModel;
    
    private final Caja caja;
    private final CajaModel cajaModel;
    
    public ConfiguracionController(Content_Configuracion contentConfiguracion, int Nivel){
        this.contentConfiguracion = contentConfiguracion;
        this.Nivel = Nivel;
        
        caja = new Caja();
        cajaModel = new CajaModel();
        configuracionModel = new ConfiguracionModel(); 
        
        init();
        contentConfiguracion.Configuracion_Modificar_Base.addActionListener(this);
        contentConfiguracion.Llave_Generador.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == contentConfiguracion.Configuracion_Modificar_Base){
            caja.setCapital(Integer.parseInt(contentConfiguracion.Configuracion_Base.getText()));
            caja.setId(1);
            if(configuracionModel.getDataConfiguracionKey(JOptionPane.showInputDialog("Por favor escribir llave de acceso: "))){
                if(cajaModel.setDataModCaja(caja) == 1){
                    JOptionPane.showMessageDialog(null, "Guardado Correctamente!!", null, JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }
        if(e.getSource() == contentConfiguracion.Llave_Generador){
            if(configuracionModel.getDataConfiguracionKey(JOptionPane.showInputDialog("Por favor escribir antigua llave de acceso: "))){
                String llave = Generador(10);
                if(configuracionModel.setDataConfiguracionKey(llave) == 1)
                    JOptionPane.showMessageDialog(null, llave + " <- guarda tu Llave de acceso para futuras modificaciones.", null, JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    
    private void init(){
        if(Nivel != 1){
            contentConfiguracion.Configuracion_Modificar_Base.setEnabled(false);
            contentConfiguracion.Llave_Generador.setEnabled(false);
            contentConfiguracion.Configuracion_Base.setEnabled(false);
        }
    }
    
    private String Generador(int value){
        String[] numero = {"1","2","3","4","5","6","7","8","9","0"};
        String[] simbolo = {"!","@","#","$","%","^","&","*","(",")","_","+","|"};
        String[] letra = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T"};
        String psw = "";
        for (int i = 0; i < value; i++) {
            psw += numero[(int) (Math.random()*9)+1] + letra[(int)(Math.random()*20)+1] + simbolo[(int)(Math.random()*12)+1];
        }
        return psw;
    }
}
