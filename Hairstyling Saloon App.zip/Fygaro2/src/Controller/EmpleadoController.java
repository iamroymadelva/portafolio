/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.EmpleadoModel;
import View.Content_Empleado;
import Params.Empleado;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author carlos_sanchez
 */
public class EmpleadoController implements ActionListener{
    
    private final EmpleadoModel empleadoModel;
    private final Content_Empleado contentEmpleado;
    private final Empleado empleado;
    
    public EmpleadoController(Content_Empleado contentEmpleado, EmpleadoModel empleadoModel){
        this.contentEmpleado = contentEmpleado;
        this.empleadoModel = empleadoModel;
        
        empleado = new Empleado();
        
        contentEmpleado.Empleado_Guardar.addActionListener(this);
        contentEmpleado.Btn_Borrar.addActionListener(this);
        contentEmpleado.Empleado_Modificar.addActionListener(this);
        contentEmpleado.Empleado_Eliminar.addActionListener(this);
        contentEmpleado.Empleado_Buscar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == contentEmpleado.Empleado_Guardar){
            if(verifyEmpleado()){
                if(empleadoModel.setDataEmpleado(getDataEmpleado()) == 1){
                    MessageSuccess("Guardado Correctamente!!");
                    EnableFalse();
                    CleanEmpleado();
                }else
                    MessageError("Ocurrio algo inesperado, intentemoslo de nuevo.");
            }
        }else if(e.getSource() == contentEmpleado.Empleado_Buscar){
                EnableFalse();
                if(verifyDocumento(contentEmpleado.Empleado_Documento.getText())){
                    if(empleadoModel.getDataEmpleadoKey(getDataEmpleado())){
                        setDataEmpleado();
                        contentEmpleado.Empleado_Modificar.setEnabled(true);
                        contentEmpleado.Empleado_Eliminar.setEnabled(true);
                        contentEmpleado.Empleado_Documento.setEnabled(false);
                    }else{
                        MessageError("No hay datos relacionados");
                        contentEmpleado.Empleado_Guardar.setEnabled(true);
                    }
                }else
                    MessageError("Por favor ingresar Documento a buscar");
        }else if(e.getSource() == contentEmpleado.Empleado_Modificar){
                if(verifyDocumento(contentEmpleado.Empleado_Documento.getText())){
                    if(empleadoModel.setUpdateDataEmpleado(getDataEmpleado()) == 1){
                        MessageSuccess("Modificado Correctamente!!");
                        contentEmpleado.Empleado_Documento.setEnabled(true);
                        EnableFalse();
                        CleanEmpleado();
                    }else
                        MessageError("Ocurrio algo inesperado, intentemoslo de nuevo.");
                }else
                    MessageError("Por favor ingresar Documento del empleado a modificar:");
                
        }else if(e.getSource() == contentEmpleado.Empleado_Eliminar){
                if(verifyDocumento(contentEmpleado.Empleado_Documento.getText())){
                    if(empleadoModel.setDeleteDataEmpleado(getDataEmpleado()) == 1){
                        MessageSuccess("Eliminado Correctamente!!");
                        contentEmpleado.Empleado_Documento.setEnabled(true);
                        EnableFalse();
                        CleanEmpleado();
                    }else
                        MessageError("Ocurrio algo inesperado, intentemoslo de nuevo.");
                }else
                    MessageError("Por favor ingresar Documento del empleado a eliminar de la base de datos");
                
        }else if(e.getSource() == contentEmpleado.Btn_Borrar){
                contentEmpleado.Empleado_Documento.setEnabled(true);
                CleanEmpleado();
                EnableFalse();
        }
    }
    
    public void CleanEmpleado(){
        contentEmpleado.Empleado_Nombre.setText(null);
        contentEmpleado.Empleado_Apellido.setText(null);
        contentEmpleado.Empleado_Documento.setText(null);
        contentEmpleado.Empleado_Celular.setText(null);
        contentEmpleado.Empleado_Telefono.setText(null);
        contentEmpleado.Empleado_Direccion.setText(null);
        contentEmpleado.Empleado_Correo.setText(null);
    }
    
    public void EnableFalse(){
        contentEmpleado.Empleado_Modificar.setEnabled(false);
        contentEmpleado.Empleado_Eliminar.setEnabled(false);
        contentEmpleado.Empleado_Guardar.setEnabled(false);
    }
    
    public void setDataEmpleado(){
        contentEmpleado.Empleado_Nombre.setText(empleado.getNombre());
        contentEmpleado.Empleado_Apellido.setText(empleado.getApellido());
        contentEmpleado.Empleado_Celular.setText(empleado.getCelular());
        contentEmpleado.Empleado_Telefono.setText(empleado.getTelefono());
        contentEmpleado.Empleado_Correo.setText(empleado.getCorreo());
        contentEmpleado.Empleado_Direccion.setText(empleado.getDireccion());
        contentEmpleado.Empleado_Fecha_Day.setSelectedItem(empleado.getFecha().split("/")[0]);
        contentEmpleado.Empleado_Fecha_Month.setSelectedItem(empleado.getFecha().split("/")[1]);
        contentEmpleado.Empleado_Fecha_Years.setSelectedItem(empleado.getFecha().split("/")[2]);
        contentEmpleado.Empleado_Genero.setSelectedItem(empleado.getGenero());
    }
    
    public boolean verifyDocumento(String valor){
        return valor.length() > 0;
    }
    
    public Empleado getDataEmpleado(){
        empleado.setNombre(contentEmpleado.Empleado_Nombre.getText().toUpperCase());
        empleado.setApellido(contentEmpleado.Empleado_Apellido.getText().toUpperCase());
        empleado.setCelular(contentEmpleado.Empleado_Celular.getText());
        empleado.setTelefono(contentEmpleado.Empleado_Telefono.getText());
        empleado.setCorreo(contentEmpleado.Empleado_Correo.getText());
        empleado.setDireccion(contentEmpleado.Empleado_Direccion.getText());
        empleado.setDocumento(Integer.parseInt(contentEmpleado.Empleado_Documento.getText()));
        empleado.setFecha(contentEmpleado.Empleado_Fecha_Day.getSelectedItem().toString()+"/"+contentEmpleado.Empleado_Fecha_Month.getSelectedItem().toString()+"/"+contentEmpleado.Empleado_Fecha_Years.getSelectedItem().toString());
        empleado.setGenero(contentEmpleado.Empleado_Genero.getSelectedItem().toString());
        return empleado;
    }
    
    public boolean verifyEmpleado(){
        if(contentEmpleado.Empleado_Nombre.getText().equals("")){
            MessageError("Campo nombre vacio");
            return false;
        }else if(contentEmpleado.Empleado_Apellido.getText().equals("")){
            MessageError("Campo apellido vacio");
            return false;
        }else if(contentEmpleado.Empleado_Documento.getText().equals("") || contentEmpleado.Empleado_Documento.getText().length() < 6 && contentEmpleado.Empleado_Documento.getText().length() > 10){
            MessageError("Numero de documento incorrecto");
            return false;
        }else if(contentEmpleado.Empleado_Celular.getText().equals("") || contentEmpleado.Empleado_Celular.getText().length() > 10 && contentEmpleado.Empleado_Celular.getText().length() < 10){
            MessageError("Numero de celular incorrecto");
            return false;
        }else if(!contentEmpleado.Empleado_Telefono.getText().equals("") && contentEmpleado.Empleado_Telefono.getText().length() < 7 && contentEmpleado.Empleado_Telefono.getText().length() > 8){
            MessageError("Numero de telefono incorrecto");
            return false;
        }else if(contentEmpleado.Empleado_Direccion.getText().equals("")){
            MessageError("Campo direccion vacio");
            return false;
        }else if(contentEmpleado.Empleado_Correo.getText().equals("") || !verifyEmail(contentEmpleado.Empleado_Correo.getText())){
            MessageError("Campo correo vacio o correo invalido");
            return false;
        }
        return true;
    }
  
    public void MessageError(String message){
        JOptionPane.showMessageDialog(null, message, null,JOptionPane.ERROR_MESSAGE);
    }
    
    public void MessageSuccess(String message){
        JOptionPane.showMessageDialog(null, message);
    }
    
    public boolean verifyEmail(String email){
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher mather = pattern.matcher(email);
        return mather.find();
    }
    
    public String formatMoney(String valor){
        DecimalFormat decimalFormat = new DecimalFormat("#,###");
        if(valor.length() > 0)
            return String.valueOf(decimalFormat.format(Integer.valueOf(valor.replace(",","").replace(".",""))));
        return "";
    }
    
}
