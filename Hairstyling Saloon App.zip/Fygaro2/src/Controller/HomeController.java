/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import View.*;
import Model.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
/**
 *
 * @author carlos_sanchez
 */
public class HomeController implements MouseListener{
    private final Home view;
    private final HomeModel model;
    private ControllerViews pushView;
    private final int range;
    
    public HomeController(Home view, HomeModel model, int range){
        this.view = view;
        this.model = model;
        this.range = range;
        
        this.view.Btn_Close.addMouseListener(this);
        this.view.Btn_Empleados.addMouseListener(this);
        this.view.Btn_Producto.addMouseListener(this);
        this.view.Btn_Venta.addMouseListener(this);
        this.view.Btn_Cliente.addMouseListener(this);
        this.view.Btn_Caja.addMouseListener(this);
        this.view.Btn_Nomina.addMouseListener(this);
        this.view.Btn_Configuracion.addMouseListener(this);
    }
    
    public void init(){
        view.setLocationRelativeTo(view);
        view.setTitle("SABARBER");
        view.setResizable(false);
        view.setVisible(true);
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == view.Btn_Empleados){
            Content_Empleado contentEmpleado = new Content_Empleado();
            EmpleadoModel empleadoModel = new EmpleadoModel();
            pushView = new ControllerViews(contentEmpleado.Panel_Empleado, view.Content_Main);
            view.Title_Home.setText("Empleado");
            EmpleadoController empleadoController = new EmpleadoController(contentEmpleado, empleadoModel);
        }
        if(e.getSource() == view.Btn_Close){
            System.exit(0);
        }
        if(e.getSource() == view.Btn_Venta){
            Content_Ventas contentVentas = new Content_Ventas();
            VentaModel ventaModel = new VentaModel();
            pushView = new ControllerViews(contentVentas.Content_Ventas, view.Content_Main);
            view.Title_Home.setText("Ventas");
            VentaController ventaController = new VentaController(contentVentas, ventaModel);
        }
        if(e.getSource() == view.Btn_Producto){
            Content_Producto contentProducto = new Content_Producto();
            ProductoModel productoModel = new ProductoModel();
            pushView = new ControllerViews(contentProducto.Content_Producto, view.Content_Main);
            view.Title_Home.setText("Producto");
            ProductoController productoController = new ProductoController(contentProducto, productoModel);
        }
        if(e.getSource() == view.Btn_Cliente){
            Content_Cliente contentCliente = new Content_Cliente();
            ClienteModel clienteModel = new ClienteModel();
            pushView = new ControllerViews(contentCliente.Content_Cliente, view.Content_Main);
            view.Title_Home.setText("Cliente");
            ClienteController clienteController = new ClienteController(contentCliente, clienteModel);
        }
        if(e.getSource() == view.Btn_Caja){
            CajaModel cajaModel = new CajaModel();
            Content_Caja contentCaja = new Content_Caja();
            pushView = new ControllerViews(contentCaja.Content_Caja, view.Content_Main);
            view.Title_Home.setText("Caja");
            CajaController cajaController = new CajaController(contentCaja, cajaModel);
        }
        if(e.getSource() == view.Btn_Nomina){
            NominaModel nominaModel = new NominaModel();
            Content_Nomina contentNomina = new Content_Nomina();
            pushView = new ControllerViews(contentNomina.Content_Nomina, view.Content_Main);
            view.Title_Home.setText("Nomina");
            NominaController nominaController = new NominaController(contentNomina, nominaModel);
        }
        if(e.getSource() == view.Btn_Configuracion){
            Content_Configuracion contentConfiguracion = new Content_Configuracion();
            pushView = new ControllerViews(contentConfiguracion.Content_Configuracion, view.Content_Main);
            view.Title_Home.setText("Configuracion");
            ConfiguracionController confiController = new ConfiguracionController(contentConfiguracion, range);
        }
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }
    
    @Override
    public void mouseExited(MouseEvent e) {
        
    }
}
