/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import View.Index;
import Model.IndexModel;
import View.Home;
import Model.HomeModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author carlos_sanchez
 */
public class IndexController implements ActionListener {
    private final Index view;
    private final IndexModel model;
    private  HomeController hcontroller = null;
    private  HomeModel hmodel = null;
    private  Home hview = null;
    private int range = 0;
    
    //constructor de la clase instanciando la vista y el modelo
    public IndexController(Index view, IndexModel model){
        this.view = view;
        this.model = model;
        
        this.view.initSession.addActionListener(this);
    }
    
    //clase init llamada para iniciar la vista 
    public void init(){
        view.setLocationRelativeTo(view);
        view.setTitle("Peluqueria XYZ");
        view.setResizable(false);
        view.setVisible(true);
    }
    
    //funcion que escucha los eventos que ocurren en las vistas 
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == view.initSession){
            if(verify(view.username.getText(), new String(view.password.getPassword()))){
                if(verifyPassword(model.searchUser(view.username.getText()), new String(view.password.getPassword()))){
                    //enviar a vista home
                    view.dispose();
                    hview = new Home();
                    hmodel = new HomeModel();
                    hcontroller = new HomeController(hview, hmodel, range);
                    hcontroller.init();
                }else
                    MessageError("Nombre de usuario o contrasena incorrecto");
            }else
                MessageError("Error faltan campos por llenar");
        }
    }
    
    
    //funcion para veirfficar que los campos no vuelvan vacios
    public boolean verify(String username,String password){
        return (!username.equals("") & !password.equals(""));
    }
    
    
    //funcion que verifica si la contrasena que se proporciona concuerda con la de la db
    public boolean verifyPassword(ResultSet rs, String Password){
        try{
            if(rs.next()){
                range = rs.getInt("Usu_Range");
                String password = rs.getString("Usu_Password");
                if(password.equals(Password))
                    return true;
                
            }
        }catch(SQLException e){}
        return  false;
    }
    
    //funcion para enviar mensajes de errores al usuario
    public void MessageError(String message){
        JOptionPane.showMessageDialog(null, message);
    }
}
