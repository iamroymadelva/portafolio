/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.EmpleadoModel;
import Model.NominaModel;
import View.Content_Nomina;
import Params.Nomina;
import Params.Empleado;
import Params.Ventas;
import View.ContentNomina_Ventas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author carlos_sanchez
 */
public class NominaController implements ActionListener, MouseListener{
    
    private final Content_Nomina contentNomina;
    private final NominaModel nominaModel;
    private final Nomina nomina;
    
    private final Empleado empleado;
    private final EmpleadoModel empleadoModel;
    
    private final ContentNomina_Ventas contentNominaVenta;
    
    public NominaController(Content_Nomina contentNomina, NominaModel nominaModel){
        this.contentNomina = contentNomina;
        this.nominaModel = nominaModel;
        
        nomina = new Nomina();
        empleado = new Empleado();
        empleadoModel = new EmpleadoModel();
        contentNominaVenta = new ContentNomina_Ventas();
        
        getDataNominaAll();
        
        contentNomina.Nomina_Generar.addActionListener(this);
        contentNomina.Nomina_Guardar.addActionListener(this);
        contentNomina.Nomina_Limpiar.addActionListener(this);
        contentNominaVenta.Nomina_Aceptar.addActionListener(this);
        contentNominaVenta.Nomina_Cancelar.addActionListener(this);
        contentNomina.Nomina_Empleado_Help.addMouseListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == contentNomina.Nomina_Generar){
            contentNomina.Nomina_Codigo.setText(GeneratorKeys()+"");
            EnabledButtons();
            setPorcentaje();
            setEmpleado();
            setFechaActual();
        }
        if(e.getSource() == contentNomina.Nomina_Guardar){
            initViewModelVentas();
            setModelTableVentasEmpleado();
        }
        if(e.getSource() == contentNomina.Nomina_Limpiar){
            CleanInputs();
        }
        if(e.getSource() == contentNominaVenta.Nomina_Aceptar){
            contentNominaVenta.dispose();
            if(nominaModel.setDataNomina(getDataNomina()) == 1){
                MessageInfo("Guardado correctamente!!");
                CleanInputs();
                getDataNominaAll();
            }else
                MessageError("Ah ocurrido algo inesperado, intentemoslo de nuevo.");
        }
        if(e.getSource() == contentNominaVenta.Nomina_Cancelar){
            contentNominaVenta.dispose();
        }
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == contentNomina.Nomina_Empleado_Help){
            setActionEmpleadoHelps(contentNomina.Nomina_Empleado.getSelectedItem().toString());
        }
    }
    
    public void EnabledButtons(){
        contentNomina.Nomina_Codigo.setEnabled(false);
        contentNomina.Nomina_Generar.setEnabled(false);
        contentNomina.Nomina_Guardar.setEnabled(true);
    }
    
    public void CleanInputs(){
        contentNomina.Nomina_Generar.setEnabled(true);
        contentNomina.Nomina_Guardar.setEnabled(false);
        contentNomina.Nomina_Codigo.setText(null);
        contentNomina.Nomina_Empleado.removeAllItems();
        contentNomina.Nomina_Fecha.setText(null);
        contentNomina.Nomina_Porcentaje.removeAllItems();
        contentNomina.Nomina_Valor.setText(null);
    }
    
    public void initViewModelVentas(){
        contentNominaVenta.setLocationRelativeTo(contentNominaVenta);
        contentNominaVenta.setResizable(false);
        contentNominaVenta.setVisible(true);
    }
    
    public void setModelTableVentasEmpleado(){
        nomina.setFecha_Inicio(contentNomina.Nomina_Fecha_Day_Inicio.getSelectedItem().toString() + "/" + contentNomina.Nomina_Fecha_Month_Inicio.getSelectedItem().toString() + "/" +contentNomina.Nomina_Fecha_Years_Inicio.getSelectedItem().toString());
        nomina.setFecha_Final(contentNomina.Nomina_Fecha_Day_Cierre.getSelectedItem().toString() + "/" + contentNomina.Nomina_Fecha_Month_Cierre.getSelectedItem().toString() + "/" +contentNomina.Nomina_Fecha_Years_Cierre.getSelectedItem().toString());
        nomina.setDocumento_Empleado(Integer.parseInt(contentNomina.Nomina_Empleado.getSelectedItem().toString()));
        ArrayList<Ventas> arrayVenta = nominaModel.getDataVentasRange(nomina);
        int total = 0;
        String[] columna = {"ID","PRODUCTO","VALOR","CANTIDAD","FECHA","DESCRIPCION","EMPLEADO","CLIENTE"};
        DefaultTableModel tableModel = new DefaultTableModel(columna,0);
        for (int i = 0; i < arrayVenta.size(); i++) {
            tableModel.addRow(new Object[] {arrayVenta.get(i).getId(),arrayVenta.get(i).getProducto(),arrayVenta.get(i).getValor(),arrayVenta.get(i).getCantidad(),arrayVenta.get(i).getFecha(),arrayVenta.get(i).getDescripcion(),arrayVenta.get(i).getEmpleado(),arrayVenta.get(i).getCliente()});
            total += (arrayVenta.get(i).getValor() * arrayVenta.get(i).getCantidad());
        }
        contentNominaVenta.Nomina_List_Venta.setModel(tableModel);
        double ftotal = total * Double.parseDouble(contentNomina.Nomina_Porcentaje.getSelectedItem().toString().replace("%",""));
        contentNominaVenta.Nomina_Valor_Total.setText(formatMoney(String.valueOf(total)));
        contentNominaVenta.Nomina_Valor_Estipulado.setText(ftotal + "");
        contentNomina.Nomina_Valor.setText(ftotal + "");
    }
    
    public void setPorcentaje(){
        contentNomina.Nomina_Porcentaje.removeAllItems();
        for (int i = 10; i < 100; i++) {
            contentNomina.Nomina_Porcentaje.addItem("0."+i+"%");
        }
    }
    
    public void setFechaActual(){
        Calendar calendar = Calendar.getInstance();
        contentNomina.Nomina_Fecha.setText(calendar.get(Calendar.DATE) + "/" +calendar.get(Calendar.MONTH) + "/" + calendar.get(Calendar.YEAR));
    }
    
    public void setEmpleado(){
    ArrayList<Empleado> arrayEmpleado;
        arrayEmpleado = empleadoModel.getDataEmpleado();
        for(int i = 0; i < arrayEmpleado.size(); i++){
            contentNomina.Nomina_Empleado.addItem(arrayEmpleado.get(i).getDocumento() + "");
        }
    }
    
    public Nomina getDataNomina(){
        nomina.setId(Integer.parseInt(contentNomina.Nomina_Codigo.getText()));
        nomina.setDocumento_Empleado(Integer.parseInt(contentNomina.Nomina_Empleado.getSelectedItem().toString()));
        nomina.setFecha(contentNomina.Nomina_Fecha.getText());
        nomina.setFecha_Inicio(contentNomina.Nomina_Fecha_Day_Inicio.getSelectedItem().toString() + "/" + contentNomina.Nomina_Fecha_Month_Inicio.getSelectedItem().toString() + "/" +contentNomina.Nomina_Fecha_Years_Inicio.getSelectedItem().toString());
        nomina.setFecha_Final(contentNomina.Nomina_Fecha_Day_Cierre.getSelectedItem().toString() + "/" + contentNomina.Nomina_Fecha_Month_Cierre.getSelectedItem().toString() + "/" +contentNomina.Nomina_Fecha_Years_Cierre.getSelectedItem().toString());
        nomina.setPorcentaje(Double.parseDouble(contentNomina.Nomina_Porcentaje.getSelectedItem().toString().replace("%", "")));
        nomina.setValor_Est(Double.parseDouble(contentNomina.Nomina_Valor.getText()));
        nomina.setCaja(Integer.parseInt(contentNomina.Nomina_Caja.getSelectedItem().toString()));
        return nomina;
    }
    
    private void getDataNominaAll(){
        ArrayList<Nomina> arrayNomina = nominaModel.getDataNominaAll();
        String[] columna = {"ID","DOCUMENTO","FECHA","FECHA INICIO", "FECHA FIN", "PORCENTAJE", "VALOR", "CAJA ID"};
        DefaultTableModel tableModel = new DefaultTableModel(columna,0);
        for(int i = 0; i < arrayNomina.size(); i++) {
            tableModel.addRow(new Object[]{arrayNomina.get(i).getId(), arrayNomina.get(i).getDocumento_Empleado(), arrayNomina.get(i).getFecha(), arrayNomina.get(i).getFecha_Inicio(), arrayNomina.get(i).getFecha_Final(), arrayNomina.get(i).getPorcentaje(), arrayNomina.get(i).getValor_Est(), arrayNomina.get(i).getCaja()});
        }
        contentNomina.Nomina_List.setModel(tableModel);
    }
    
    public int GeneratorKeys(){
        ArrayList<Integer> key = new ArrayList<>(99999);
        for(int i = 70000; i < 99999; i++){
            key.add(i);
        }
        Random random = new Random();
        int number = 0;
        boolean sw = true;
        while(sw){
            if(key.size() > 0){
                number = random.nextInt(key.size());
                key.remove(number);
                nomina.setId(number);
                if(!nominaModel.getDataNominaKey(nomina))
                    sw = false;
            }
        }
        return number;
    }
    
    public void setActionEmpleadoHelps(String documento){
        empleado.setDocumento(Integer.parseInt(documento));
        if(empleadoModel.getDataEmpleadoKey(empleado)){
            MessageInfo(empleado.getNombre() + " " + empleado.getApellido());
        }
    }
    
    public void MessageError(String message){
        JOptionPane.showMessageDialog(null, message, null, JOptionPane.ERROR_MESSAGE);
    }
    
    public String formatMoney(String valor){
        DecimalFormat decimalFormat = new DecimalFormat("#,###");
        return String.valueOf(decimalFormat.format(Integer.parseInt(valor.replace(".",""))));
    }
    
    public void MessageInfo(String message){
        JOptionPane.showMessageDialog(null, message, null, JOptionPane.INFORMATION_MESSAGE);
    }

    

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
