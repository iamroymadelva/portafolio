/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.ProductoModel;
import View.Content_Producto;
import Params.Producto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;


/**
 *
 * @author carlos_sanchez
 */
public class ProductoController implements  ActionListener, KeyListener{
    
    private final Content_Producto contentProducto;
    private final ProductoModel productoModel;
    private final Producto producto;
    
    public ProductoController(Content_Producto contentPtoducto, ProductoModel productoModel){
        this.contentProducto = contentPtoducto;
        this.productoModel = productoModel;
        
        producto = new Producto();
        
        contentProducto.Producto_Buscar.addActionListener(this);
        contentProducto.Producto_Guardar.addActionListener(this);
        contentProducto.Producto_Modificar.addActionListener(this);
        contentProducto.Producto_Eliminar.addActionListener(this);
        contentProducto.Producto_Limpiar.addActionListener(this);
        contentProducto.Producto_Generar.addActionListener(this);
        
        contentProducto.Producto_Valor.addKeyListener(this);
        contentProducto.Producto_Descripcion.addKeyListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == contentProducto.Producto_Generar){
            contentProducto.Producto_Codigo.setText(GeneratorKeys()+"");
            EnableFalseProducto();
            contentProducto.Producto_Guardar.setEnabled(true);
        }
        if(e.getSource() == contentProducto.Producto_Buscar){
            if(verifyDocumento(contentProducto.Producto_Codigo.getText())){
                if(productoModel.getDataProductoKey(getDataProducto())){
                    EnableFalseProducto();
                    setDataProducto();
                    contentProducto.Producto_Eliminar.setEnabled(true);
                    contentProducto.Producto_Modificar.setEnabled(true);
                }else{
                    MessageError("No se encuentran datos relacionados");
                }
            }else
                MessageError("Por favor introducir documento a buscar.");
        }
        if(e.getSource() == contentProducto.Producto_Guardar){
            if(verifyProducto()){
                if(productoModel.setDataProducto(getDataProducto()) == 1){
                    MessageSuccess("Guardado Correctamente!!");
                    EnableFalseProducto();
                    EnabledDefault();
                    CleanProducto();
                }else
                    MessageError("Ocurrio algo inesperado, intentemoslo de nuevo.");
            }
        }
        if(e.getSource() == contentProducto.Producto_Modificar){
            if(verifyDocumento(contentProducto.Producto_Codigo.getText())){
                if(productoModel.setUpdateProducto(getDataProducto()) == 1){
                    MessageSuccess("Modificado Correctamente!!");
                    CleanProducto();
                    EnableFalseProducto();
                    EnabledDefault();
                }else
                    MessageError("Ocurrio algo inesperado, intentemoslo de nuevo.");
            }else
                MessageError("Por favor introducir el codigo del producto a modificar");
        }else if(e.getSource() == contentProducto.Producto_Eliminar){
            if(verifyDocumento(contentProducto.Producto_Codigo.getText())){
                if(productoModel.setDeleteProducto(getDataProducto()) == 1){
                    MessageSuccess("Eliminado correctamente!!");
                    CleanProducto();
                    EnableFalseProducto();
                    EnabledDefault();
                }else
                    MessageError("Ocurrio algo inesperado, intentemoslo de nuevo.");
            }
        }else if(e.getSource() == contentProducto.Producto_Limpiar){
            CleanProducto();
            EnableFalseProducto();
            EnabledDefault();
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource() == contentProducto.Producto_Valor){
            contentProducto.Producto_Valor.setText(formatMoney(contentProducto.Producto_Valor.getText()));
        }
        if(e.getSource() == contentProducto.Producto_Descripcion){
            if(contentProducto.Producto_Descripcion.getText().length() > 49)
                MessageError("Caracteres permitidos agotados");
        }
    }
    
    public void CleanProducto(){
        contentProducto.Producto_Codigo.setText(null);
        contentProducto.Producto_Nombre.setText(null);
        contentProducto.Producto_Valor.setText(null);
        contentProducto.Producto_Descripcion.setText(null);
    }
    
    public void EnableFalseProducto(){
        contentProducto.Producto_Codigo.setEnabled(false);
        contentProducto.Producto_Buscar.setEnabled(false);
        contentProducto.Producto_Eliminar.setEnabled(false);
        contentProducto.Producto_Guardar.setEnabled(false);
        contentProducto.Producto_Modificar.setEnabled(false);
        contentProducto.Producto_Generar.setEnabled(false);
    }
    
    public void EnabledDefault(){
        contentProducto.Producto_Codigo.setEnabled(true);
        contentProducto.Producto_Buscar.setEnabled(true);
        contentProducto.Producto_Generar.setEnabled(true);
    }
    
    public void setDataProducto(){
        contentProducto.Producto_Nombre.setText(producto.getNombre());
        contentProducto.Producto_Valor.setText(formatMoney(producto.getValor() + ""));
        contentProducto.Producto_Descripcion.setText(producto.getDescripcion());
    }
    
    public Producto getDataProducto(){
        producto.setId(contentProducto.Producto_Codigo.getText());
        producto.setNombre(contentProducto.Producto_Nombre.getText().toUpperCase());
        if(!contentProducto.Producto_Valor.getText().equals(""))
            producto.setValor(Integer.parseInt(contentProducto.Producto_Valor.getText().replace(".","")));
        producto.setDescripcion(contentProducto.Producto_Descripcion.getText());
        return producto;
    }
    
    public boolean verifyProducto(){
        if(contentProducto.Producto_Codigo.getText().equals("")){
            MessageError("Campo codigo vacio");
            return false;
        }else if(contentProducto.Producto_Nombre.getText().equals("")){
            MessageError("Campo nombre vacio");
            return false;
        }else if(contentProducto.Producto_Valor.getText().equals("")){
            MessageError("Campo valor vacio");
            return false;
        }else if(contentProducto.Producto_Descripcion.getText().equals("")){
            MessageError("Campo Decripcion vacio");
            return false;
        }
        return true;
    }
    
    public int GeneratorKeys(){
        ArrayList<Integer> key = new ArrayList<>(99999);
        for(int i = 30000; i < 49999; i++){
            key.add(i);
        }
        Random random = new Random();
        int number = 0;
        boolean sw = true;
        while(sw){
            if(key.size() > 0){
                number = random.nextInt(key.size());
                key.remove(number);
                producto.setId(number+"");
                if(!productoModel.getDataProductoKey(producto))
                    sw = false;
            }
        }
        return number;
    }
    
    public boolean verifyDocumento(String valor){
        return valor.length() > 0;
    }
    
    public void MessageError(String message){
        JOptionPane.showMessageDialog(null, message, null,JOptionPane.ERROR_MESSAGE);
    }
    
    public void MessageSuccess(String message){
        JOptionPane.showMessageDialog(null, message);
    }
    
    public String formatMoney(String valor){
        DecimalFormat decimalFormat = new DecimalFormat("#,###");
        return String.valueOf(decimalFormat.format(Integer.parseInt(valor.replace(".",""))));
    }
}
