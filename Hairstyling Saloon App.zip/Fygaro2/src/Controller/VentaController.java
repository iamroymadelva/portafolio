/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.*;
import View.Content_Ventas;
import Params.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author carlos_sanchez
 */
public class VentaController implements ActionListener, MouseListener, KeyListener, ItemListener{
    
    private final Content_Ventas contentVenta;
    private final VentaModel ventaModel;
    private final Ventas venta;
    
    private final Producto producto;
    private final ProductoModel productoModel;
    
    private final Empleado empleado;
    private final EmpleadoModel empleadoModel;
    
    private final Cliente cliente;
    private final ClienteModel clienteModel;
    
    private final Caja caja;
    private final CajaModel cajaModel;
    
    public VentaController(Content_Ventas contentVentas, VentaModel ventaModel){
        this.contentVenta = contentVentas;
        this.ventaModel = ventaModel;
        
        venta = new Ventas();
        producto = new Producto();
        empleado = new Empleado();
        cliente = new Cliente();
        caja = new Caja();
        
        productoModel = new ProductoModel();
        empleadoModel = new EmpleadoModel();
        clienteModel = new ClienteModel();
        cajaModel = new CajaModel();
        
        contentVenta.Venta_Buscar.addActionListener(this);
        contentVenta.Venta_Generar.addActionListener(this);
        contentVenta.Venta_Guardar.addActionListener(this);
        contentVenta.Venta_Limpiar.addActionListener(this);
        
        contentVenta.Venta_Valor_Mod.addMouseListener(this);
        contentVenta.Venta_Producto_Help.addMouseListener(this);
        contentVenta.Venta_Empleado_Help.addMouseListener(this);
        contentVenta.Venta_Cliente_Help.addMouseListener(this);
        
        contentVenta.Venta_Producto.addItemListener(this);
        
        contentVenta.Venta_Subtotal.addKeyListener(this);
        contentVenta.Venta_Total.addKeyListener(this);
        contentVenta.Venta_Valor.addKeyListener(this);
        contentVenta.Venta_Cantidad.addKeyListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == contentVenta.Venta_Buscar){
            if(verifyCodigo(contentVenta.Venta_Codigo.getText())){
                if(ventaModel.getDataVentaKey(getDataVenta())){
                    EnabledButtons();
                    setDataVenta();
                }else
                    MessageError("No se encontraron datos relacionados.");
            }
        }
        if(e.getSource() == contentVenta.Venta_Generar){
            contentVenta.Venta_Codigo.setText(GeneratorKeys()+"");
            EnabledButtons();
            contentVenta.Venta_Guardar.setEnabled(true);
            setItemValues();
            setFechaActual();
        }
        if(e.getSource() == contentVenta.Venta_Guardar){
            if(JOptionPane.showConfirmDialog(null, "Una vez guardado no podra modificar ni eliminar los datos, desea realizar la accion?") == 0){
                if(verifyDataVenta()){
                    if(ventaModel.setDataVenta(getDataVenta()) == 1){
                        MessageInfo("Guardado correctamente!!");
                        CleanVenta();
                    }else
                        MessageError("Ocurrio algo inesperado, intentemoslo de nuevo.");
                }
            }
        }
        if(e.getSource() == contentVenta.Venta_Limpiar){
            EnabledButtons();
            EnabledDefault();
            CleanVenta();
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == contentVenta.Venta_Valor_Mod){
            MessageInfo("Se alterara un valor estatico esta accion debera contener una descripcion al respecto.");
            contentVenta.Venta_Valor.setEnabled(true);
        }
        if(e.getSource() == contentVenta.Venta_Producto_Help){
            setActionProductoHelps(contentVenta.Venta_Producto.getSelectedItem().toString());
        }
        if(e.getSource() == contentVenta.Venta_Empleado_Help){
            setActionEmpleadoHelps(contentVenta.Venta_Empleado.getSelectedItem().toString());
        }
        if(e.getSource() == contentVenta.Venta_Cliente_Help){
            setActionClienteHelps(contentVenta.Venta_Cliente.getSelectedItem().toString());
        }
    }
    
    @Override
    public void itemStateChanged(ItemEvent e) {
        if(e.getSource() == contentVenta.Venta_Producto){
            getValorProducto();
        }
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource() == contentVenta.Venta_Cantidad){
            setValue();
            contentVenta.Venta_Valor.setText(formatMoney(contentVenta.Venta_Valor.getText()));
            contentVenta.Venta_Total.setText(formatMoney(contentVenta.Venta_Total.getText()));
        }
    }
    
    public void EnabledButtons(){
        contentVenta.Venta_Codigo.setEnabled(false);
        contentVenta.Venta_Buscar.setEnabled(false);
        contentVenta.Venta_Generar.setEnabled(false);
        contentVenta.Venta_Guardar.setEnabled(false);
        contentVenta.Venta_Valor.setEnabled(false);
    }
    
    public void EnabledDefault(){
        contentVenta.Venta_Codigo.setEnabled(true);
        contentVenta.Venta_Buscar.setEnabled(true);
        contentVenta.Venta_Generar.setEnabled(true);
    }

    public Ventas getDataVenta(){
        venta.setId(Integer.parseInt(contentVenta.Venta_Codigo.getText()));
        if(contentVenta.Venta_Producto.getSelectedItem() != null)
            venta.setProducto(Integer.parseInt(contentVenta.Venta_Producto.getSelectedItem().toString()));
        if(contentVenta.Venta_Cliente.getSelectedItem() != null)
            venta.setCliente(Integer.parseInt(contentVenta.Venta_Cliente.getSelectedItem().toString()));
        if(contentVenta.Venta_Empleado.getSelectedItem() != null)
            venta.setEmpleado(Integer.parseInt(contentVenta.Venta_Empleado.getSelectedItem().toString()));
        if(contentVenta.Venta_Caja.getSelectedItem() != null)
            venta.setCaja(Integer.parseInt(contentVenta.Venta_Caja.getSelectedItem().toString()));
        if(!contentVenta.Venta_Valor.getText().equals(""))
            venta.setValor(Integer.parseInt(contentVenta.Venta_Valor.getText().replace(".","")));
        venta.setDescripcion(contentVenta.Venta_Descripcion.getText());
        if(!contentVenta.Venta_Cantidad.getText().equals(""))
            venta.setCantidad(Integer.parseInt(contentVenta.Venta_Cantidad.getText()));
        venta.setFecha(contentVenta.Venta_Fecha.getText());
        return venta;
    }
    
    public void setDataVenta(){
        contentVenta.Venta_Producto.removeAllItems();
        contentVenta.Venta_Cliente.removeAllItems();
        contentVenta.Venta_Empleado.removeAllItems();
        contentVenta.Venta_Caja.removeAllItems();
        contentVenta.Venta_Producto.addItem(String.valueOf(venta.getProducto()));
        contentVenta.Venta_Cliente.addItem(String.valueOf(venta.getCliente()));
        contentVenta.Venta_Empleado.addItem(String.valueOf(venta.getEmpleado()));
        contentVenta.Venta_Caja.addItem(String.valueOf(venta.getCaja()));
        contentVenta.Venta_Valor.setText(String.valueOf(venta.getValor()));
        contentVenta.Venta_Cantidad.setText(String.valueOf(venta.getCantidad()));
        contentVenta.Venta_Descripcion.setText(venta.getDescripcion());
        contentVenta.Venta_Fecha.setText(venta.getFecha());
        setValue();
    }
    
    public void CleanVenta(){
        contentVenta.Venta_Producto.removeAllItems();
        contentVenta.Venta_Cliente.removeAllItems();
        contentVenta.Venta_Empleado.removeAllItems();
        contentVenta.Venta_Caja.removeAllItems();
        contentVenta.Venta_Valor.setText("");
        contentVenta.Venta_Subtotal.setText("");
        contentVenta.Venta_Total.setText("");
        contentVenta.Venta_Cantidad.setText("");
        contentVenta.Venta_Descripcion.setText("");
        contentVenta.Venta_Fecha.setText("");
        contentVenta.Venta_Codigo.setText(null);
    }
    
    public boolean verifyDataVenta(){
        if(contentVenta.Venta_Codigo.getText().equals("")){
            MessageError("Campo Id invalido o vacio.");
            return false;
        }else if(contentVenta.Venta_Producto.getSelectedItem() == null){
            MessageError("No se ha seleccionado ningun Producto.");
            return false;
        }else if(contentVenta.Venta_Empleado.getSelectedItem() == null){
            MessageError("No se ha seleccionado ningun Empleado.");
            return false;
        }else if(contentVenta.Venta_Caja.getSelectedItem() == null){
            MessageError("No se ha seleccionado ninguna Caja.");
            return false;
        }else if(contentVenta.Venta_Valor.getText() == null){
            MessageError("Campo valor invalido o vacio.");
        }else if(contentVenta.Venta_Descripcion.getText().equals("")){
            MessageError("Campo Descripcion invalido o vacio.");
            return false;
        }else if(contentVenta.Venta_Cantidad.getText().equals("")){
            MessageError("Campo Cantidad invalido o vacio.");
            return false;
        }
        return true;
    }
    
    public String formatMoney(String valor){
        DecimalFormat decimalFormat = new DecimalFormat("#,###");
        return String.valueOf(decimalFormat.format(Integer.parseInt(valor.replace(".",""))));
    }
    
    public void MessageInfo(String message){
        JOptionPane.showMessageDialog(null, message, null, JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void MessageError(String message){
        JOptionPane.showMessageDialog(null, message, null, JOptionPane.ERROR_MESSAGE);
    }
    
    public boolean verifyCodigo(String value){
        return value.length() > 0;
    }
    
    public int GeneratorKeys(){
        ArrayList<Integer> key = new ArrayList<>(99999);
        for(int i = 60000; i < 99999; i++){
            key.add(i);
        }
        Random random = new Random();
        int number = 0;
        boolean sw = true;
        while(sw){
            if(key.size() > 0){
                number = random.nextInt(key.size());
                key.remove(number);
                venta.setId(number);
                if(!ventaModel.getDataVentaKey(venta))
                    sw = false;
            }
        }
        return number;
    }
    
    public void setValue(){
        if(contentVenta.Venta_Cantidad.getText() != null){
            double IVA = 0.19;
            int valor = Integer.parseInt(contentVenta.Venta_Valor.getText().replace(".",""));
            int cantidad = Integer.parseInt(contentVenta.Venta_Cantidad.getText().replace(".",""));
            double subtotal = (valor * cantidad) * IVA;
            contentVenta.Venta_Subtotal.setText(subtotal + "");
            int total = valor * cantidad;
            contentVenta.Venta_Total.setText(total + "");
        }
    }
    
    public void setItemValues(){
        ArrayList<Producto> arrayProducto;
        arrayProducto = productoModel.getDataProducto();
        for(int i = 0; i < arrayProducto.size(); i++){
            contentVenta.Venta_Producto.addItem(arrayProducto.get(i).getId());
        }
        
        ArrayList<Empleado> arrayEmpleado;
        arrayEmpleado = empleadoModel.getDataEmpleado();
        for(int i = 0; i < arrayEmpleado.size(); i++){
            contentVenta.Venta_Empleado.addItem(arrayEmpleado.get(i).getDocumento() + "");
        }
        
        ArrayList<Cliente> arrayCliente;
        arrayCliente = clienteModel.getDataCliente();
        for(int i = 0; i < arrayCliente.size(); i++){
            contentVenta.Venta_Cliente.addItem(arrayCliente.get(i).getId() + "");
        }
        
        if(cajaModel.getAllDataCaja(caja)){
            contentVenta.Venta_Caja.addItem(caja.getId() + "");
        }
    }
    
    public void getValorProducto(){
        if(contentVenta.Venta_Producto.getSelectedItem() != null){
            producto.setId(contentVenta.Venta_Producto.getSelectedItem().toString());
            if(productoModel.getDataProductoKey(producto)){
                contentVenta.Venta_Valor.setText(producto.getValor() + "");
            }
        }
    }
    
    public void setFechaActual(){
        Calendar calendar = Calendar.getInstance();
        contentVenta.Venta_Fecha.setText(calendar.get(Calendar.DATE) + "/" +calendar.get(Calendar.MONTH) + "/" + calendar.get(Calendar.YEAR));
    }
    
    public void setActionProductoHelps(String codigo){
        producto.setId(codigo);
        if(productoModel.getDataProductoKey(producto)){
            MessageInfo(producto.getNombre());
        }
    }
    
    public void setActionEmpleadoHelps(String documento){
        empleado.setDocumento(Integer.parseInt(documento));
        if(empleadoModel.getDataEmpleadoKey(empleado)){
            MessageInfo(empleado.getNombre() + " " + empleado.getApellido());
        }
    }
    
    public void setActionClienteHelps(String codigo){
        cliente.setId(Integer.parseInt(codigo));
        if(clienteModel.getDataClienteKey(cliente)){
            MessageInfo(cliente.getNombre() + " " + cliente.getApellido());
        }
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }
    
}
