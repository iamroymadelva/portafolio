/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Params.Caja;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author carlos_sanchez
 */
public class CajaModel {
    
    private final Mysql db;
    
    public CajaModel(){
        db = new Mysql();
    }
    
    public int setDataModCaja(Caja caja){
        String sql = "UPDATE Tbl_Caja SET Caj_Capital = ? WHERE Caj_Id = ?;";
        this.db.query(sql);
        this.db.statementInt(1, caja.getCapital());
        this.db.statementInt(2, caja.getId());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }
        return 0;
    }
    
    public boolean getAllDataCaja(Caja caja){
        String sql = "SELECT * FROM Tbl_Caja;";
        this.db.query(sql);
        ResultSet rs = this.db.execute();
        try{
            if(rs != null && rs.next()){
                caja.setId(rs.getInt("Caj_Id"));
                caja.setCapital(rs.getInt("Caj_Capital"));
                return true;
            }
        }catch(SQLException e){}
        
        return false;
    }
}
