/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Params.Cliente;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author carlos_sanchez
 */
public class ClienteModel extends Mysql{
    
    private final Mysql db;
    
    public ClienteModel(){
        this.db = new Mysql();
    }
    
    public int setDataCliente(Cliente cliente){
        String sql = "INSERT INTO Tbl_Cliente (Cli_Id, Cli_Nombre, Cli_Apellido, Cli_Telefono, Cli_Celular, Cli_Correo, Cli_FechaNa) VALUES (?,?,?,?,?,?,?);";
        this.db.query(sql);
        this.db.statementInt(1, cliente.getId());
        this.db.statementString(2, cliente.getNombre());
        this.db.statementString(3, cliente.getApellido());
        this.db.statementString(4, cliente.getTelefono());
        this.db.statementString(5, cliente.getCelular());
        this.db.statementString(6, cliente.getCorreo());
        this.db.statementString(7, cliente.getFecha());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }else
            this.db.rolback();
        return 0;
    }
    
    public int setUpdateDataCliente(Cliente cliente){
        String sql = "UPDATE Tbl_Cliente SET Cli_Nombre = ?, Cli_Apellido = ?, Cli_Telefono = ?, Cli_Celular = ?, Cli_Correo = ?, Cli_FechaNa = ? WHERE Cli_Id = ?;";
        this.db.query(sql);
        this.db.statementString(1, cliente.getNombre());
        this.db.statementString(2, cliente.getApellido());
        this.db.statementString(3, cliente.getTelefono());
        this.db.statementString(4, cliente.getCelular());
        this.db.statementString(5, cliente.getCorreo());
        this.db.statementString(6, cliente.getFecha());
        this.db.statementInt(7, cliente.getId());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }else
            this.db.rolback();
        return 0;
    }
    
    public int setDeleteDataCliente(Cliente cliente){
        String sql = "DELETE FROM Tbl_Cliente WHERE Cli_Id = ?;";
        this.db.query(sql);
        this.db.statementInt(1, cliente.getId());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }else
            this.db.rolback();
        return 0;
    }
    
    public boolean getDataClienteKey(Cliente cliente){
        String sql = "SELECT * FROM Tbl_Cliente WHERE Cli_Id = ?;";
        this.db.query(sql);
        this.db.statementInt(1, cliente.getId());
        ResultSet rs = this.db.execute();
        try{
            if(rs != null && rs.next()){
                cliente.setNombre(rs.getString(2));
                cliente.setApellido(rs.getString(3));
                cliente.setCelular(rs.getString(4));
                cliente.setTelefono(rs.getString(5));
                cliente.setCorreo(rs.getString(6));
                cliente.setFecha(rs.getString(7));
                return true;
            }
        }catch(SQLException e){}
        return false;
    }
    
    public ArrayList<Cliente> getDataCliente(){
        ArrayList<Cliente> clienteArray = new ArrayList<>();
        String sql = "SELECT * FROM Tbl_Cliente;";
        this.db.query(sql);
        ResultSet rs = this.db.execute();
        try{
            while(rs != null && rs.next()){
                clienteArray.add(new Cliente(rs.getInt("Cli_Id"),rs.getString("Cli_Nombre"),rs.getString("Cli_Apellido"),rs.getString("Cli_Telefono"),rs.getString("Cli_Celular"),rs.getString("Cli_FechaNa"),rs.getString("Cli_Correo"),rs.getString("Cli_Genero")));
            }
        }catch(SQLException e){}
        return clienteArray;
    }
}
