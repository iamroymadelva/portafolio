/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author carlos_sanchez
 */
public class ConfiguracionModel {
    
    private final Mysql db;
    
    public ConfiguracionModel(){
        this.db = new Mysql();
    }
    
    public int setDataConfiguracionKey(String key){
        String sql = "UPDATE Tbl_Configuracion SET Con_LlaveAcceso = ? WHERE Con_Id = 1;";
        this.db.query(sql);
        this.db.statementString(1, key);
        if(this.db.executeUpdate()==1){
            this.db.commit();
            return 1;
        }
        return 0;
    }
    
    public boolean getDataConfiguracionKey(String key){
        String sql = "SELECT * FROM Tbl_Configuracion WHERE Con_LlaveAcceso = ?;";
        this.db.query(sql);
        this.db.statementString(1, key);
        ResultSet rs = this.db.execute();
        try {
            if(rs != null && rs.next()){
                return true;
            }
        } catch (SQLException e) {
        }
        return false;
    }
}
