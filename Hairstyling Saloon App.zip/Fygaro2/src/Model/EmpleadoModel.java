/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Params.Empleado;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author carlos_sanchez
 */
public class EmpleadoModel extends Mysql{
    
    private final Mysql db;
    
    public EmpleadoModel(){
        this.db = new Mysql();
    }
    
    public int setDataEmpleado(Empleado empleado){
        String sql = "INSERT INTO Tbl_Empleado (Emp_Nombre, Emp_Apellido, Emp_Telefono, Emp_Celular, Emp_Correo, Emp_FechaNa, Emp_Direccion, Emp_Genero, Emp_Documento) VALUES (?,?,?,?,?,?,?,?,?);";
        this.db.query(sql);
        this.db.statementString(1, empleado.getNombre());
        this.db.statementString(2, empleado.getApellido());
        this.db.statementString(3, empleado.getTelefono());
        this.db.statementString(4, empleado.getCelular());
        this.db.statementString(5, empleado.getCorreo());
        this.db.statementString(6, empleado.getFecha());
        this.db.statementString(7, empleado.getDireccion());
        this.db.statementString(8, empleado.getGenero());
        this.db.statementInt(9, empleado.getDocumento());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }else
            this.db.rolback();
        return 0;
    }
    
    public int setDeleteDataEmpleado(Empleado empleado){
        String sql = "DELETE FROM Tbl_Empleado WHERE Emp_Documento = ?;";
        this.db.query(sql);
        this.db.statementInt(1, empleado.getDocumento());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }else
            this.db.rolback();
        return 0;
    }
    
    public int setUpdateDataEmpleado(Empleado empleado){
        String sql = "UPDATE Tbl_Empleado SET Emp_Nombre = ?, Emp_Apellido = ?, Emp_Telefono = ?, Emp_Celular = ?, Emp_Correo = ?, Emp_FechaNa = ?, Emp_Direccion = ?, Emp_Genero = ? WHERE Emp_Documento = ?;";
        this.db.query(sql);
        this.db.statementString(1, empleado.getNombre());
        this.db.statementString(2, empleado.getApellido());
        this.db.statementString(3, empleado.getTelefono());
        this.db.statementString(4, empleado.getCelular());
        this.db.statementString(5, empleado.getCorreo());
        this.db.statementString(6, empleado.getFecha());
        this.db.statementString(7, empleado.getDireccion());
        this.db.statementString(8, empleado.getGenero());
        this.db.statementInt(9, empleado.getDocumento());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }else
            this.db.rolback();
        return 0;
    }
    
    public ArrayList<Empleado> getDataEmpleado(){
        ArrayList<Empleado> empleadoArray = new ArrayList<>();
        String sql = "SELECT * FROM Tbl_Empleado;";
        this.db.query(sql);
        ResultSet rs = this.db.execute();
        try{
            while(rs != null && rs.next()){
                empleadoArray.add(new Empleado(rs.getString("Emp_Nombre"),rs.getString("Emp_Apellido"),rs.getString("Emp_Genero"),rs.getInt("Emp_Documento"),rs.getString("Emp_FechaNa"),rs.getString("Emp_Direccion"),rs.getString("Emp_Telefono"),rs.getString("Emp_Celular"),rs.getString("Emp_Correo")));
            }
        }catch(SQLException e){}
        return empleadoArray;
    }
    
    public boolean getDataEmpleadoKey(Empleado empleado){
        String sql = "SELECT * FROM Tbl_Empleado WHERE Emp_Documento = ?;";
        this.db.query(sql);
        this.db.statementInt(1, empleado.getDocumento());
        ResultSet rs = this.db.execute();
        try{
            if(rs.next()){
                empleado.setNombre(rs.getString("Emp_Nombre"));
                empleado.setApellido(rs.getString("Emp_Apellido"));
                empleado.setTelefono(rs.getString("Emp_Telefono"));
                empleado.setCelular(rs.getString("Emp_Celular"));
                empleado.setCorreo(rs.getString("Emp_Correo"));
                empleado.setDocumento(rs.getInt("Emp_Documento"));
                empleado.setFecha(rs.getString("Emp_FechaNa"));
                empleado.setDireccion(rs.getString("Emp_Direccion"));
                empleado.setGenero(rs.getString("Emp_Genero"));
                return true;
            }
        }catch(SQLException e){System.out.println(e);}
        return false;
    }
    
}