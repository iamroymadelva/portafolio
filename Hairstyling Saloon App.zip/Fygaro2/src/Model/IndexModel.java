/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.ResultSet;
/**
 *
 * @author carlos_sanchez
 */
public class IndexModel extends Mysql{
    private final Mysql db;
    
    public IndexModel(){
        this.db = new Mysql();
    }
    
    //devolvemos un resulset que trae consigo el resultado de la consulta sql
    public ResultSet searchUser(String Username){
        String sql = "SELECT * FROM Tbl_Usuario WHERE Usu_Username = ?";
        this.db.query(sql);
        this.db.statementString(1, Username);
        return this.db.execute();
    }
    
}
