/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author carlos_sanchez
 */
public class Mysql {
    private final String base = "Bd_Peluqueria";
    private final String user = "root";
    private final String password = "19972107CaS_";
    private final int port = 3306;
    private final String host = "localhost";
    String url = String.format("jdbc:mysql://%s:%d/%s?useSSL=false", host, port, base);
    private Connection query = null;
    private PreparedStatement stm = null;
    
    public Mysql(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            query = (Connection) DriverManager.getConnection(this.url, this.user, this.password);
            query.setAutoCommit(false);
        } catch(SQLException e){
            System.err.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Mysql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void query(String sql){
        try{stm = query.prepareStatement(sql);}catch(SQLException e){}
    }
    
    public void statementInt(int item,int value){
        try{stm.setInt(item, value);}catch(SQLException e){}
    }
    
    public void statementString(int item,String value){
        try{stm.setString(item, value);}catch(SQLException e){}
    }
    
    public void statementDouble(int item,double value){
        try{stm.setDouble(item, value);}catch(SQLException e){}
    }
    
    public ResultSet execute(){
        try{return stm.executeQuery();}catch(SQLException e){}
        return null;
    }
    
    public int executeUpdate(){
        try{return stm.executeUpdate();}catch(SQLException e){}
        return 0;
    }
    
    public void commit(){
        try {
            query.commit();
        } catch (SQLException ex) {
            Logger.getLogger(Mysql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void rolback(){
        try {
            query.rollback();
        } catch (SQLException ex) {
            Logger.getLogger(Mysql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
