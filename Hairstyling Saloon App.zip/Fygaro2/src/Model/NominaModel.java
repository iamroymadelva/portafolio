/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import Params.Nomina;
import Params.Ventas;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author carlos_sanchez
 */
public class NominaModel {
    
    private final Mysql db;
    
    public NominaModel(){
        this.db = new Mysql();
    }
    
    public boolean getDataNominaKey(Nomina nomina){
        String sql = "SELECT * FROM Tbl_Nomina WHERE Nom_Id = ?";
        this.db.query(sql);
        this.db.statementInt(1, nomina.getId());
        ResultSet rs = this.db.execute();
        try {
            if(rs != null && rs.next()){
                return true;
            }
        }catch(SQLException e){}
        return false;
    }
    
    public int setDataNomina(Nomina nomina){
        String sql = "INSERT INTO Tbl_Nomina (Nom_Id, Nom_Fecha, Nom_Porcentaje, Nom_ValorEs, Tbl_Empleado_Emp_Documento, Tbl_Caja_Caj_Id, Nom_Fecha_Liquidacion_Inicio, Nom_Fecha_Liquidacion_Final) VALUES (?,?,?,?,?,?,?,?);";
        this.db.query(sql);
        this.db.statementInt(1, nomina.getId());
        this.db.statementString(2, nomina.getFecha());
        this.db.statementDouble(3, nomina.getPorcentaje());
        this.db.statementDouble(4, nomina.getValor_Est());
        this.db.statementInt(5, nomina.getDocumento_Empleado());
        this.db.statementInt(6, nomina.getCaja());
        this.db.statementString(7, nomina.getFecha_Inicio());
        this.db.statementString(8, nomina.getFecha_Final());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }
        return 0;
    }
    
    public ArrayList<Ventas> getDataVentasRange(Nomina nomina){
        ArrayList<Ventas> arrayVenta = new ArrayList<>();
        String sql = "SELECT " +
            "    venta.*" +
            " FROM " +
            "    Tbl_Ventas AS venta " +
            " WHERE venta.Tbl_Empleado_Emp_Documento = ? AND venta.Ven_Fecha BETWEEN " +
            "     ? AND ?;";
        this.db.query(sql);
        this.db.statementInt(1, nomina.getDocumento_Empleado());
        this.db.statementString(2, nomina.getFecha_Inicio());
        this.db.statementString(3, nomina.getFecha_Final());
        ResultSet rs = this.db.execute();
        try{
            while(rs != null && rs.next()){
                arrayVenta.add(new Ventas(rs.getInt("Ven_Id"), rs.getInt("Ven_Cantidad"), rs.getInt("Ven_Valor"), rs.getString("Ven_Fecha"), rs.getString("Ven_Descripcion"),rs.getInt("Tbl_Empleado_Emp_Documento"), rs.getInt("Tbl_Cliente_Cli_Id"), rs.getInt("Tbl_Producto_Pro_Id"), rs.getInt("Tbl_Caja_Caj_Id")));
            }
        }catch(SQLException e){
            System.out.println(e);
        }
        return arrayVenta;
    }
    
    public ArrayList<Nomina> getDataNominaAll(){
        ArrayList<Nomina> nominaArray = new ArrayList<>();
        String sql = "SELECT * FROM Tbl_Nomina;";
        this.db.query(sql);
        ResultSet rs = this.db.execute();
        try {
            while(rs != null && rs.next()){
                nominaArray.add(new Nomina(rs.getInt("Nom_Id"), rs.getString("Nom_Fecha"), rs.getString("Nom_Fecha_Liquidacion_Inicio"), rs.getString("Nom_Fecha_Liquidacion_Final"), rs.getInt("Tbl_Caja_Caj_Id"), rs.getDouble("Nom_Porcentaje"), rs.getDouble("Nom_ValorEs"), rs.getInt("Tbl_Empleado_Emp_Documento")));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return nominaArray;
    } 
}
