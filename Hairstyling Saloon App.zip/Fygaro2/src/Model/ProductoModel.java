/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Params.Producto;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author carlos_sanchez
 */
public class ProductoModel extends Mysql{
    
    private final Mysql db;
    
    public ProductoModel(){
        this.db = new Mysql();
    }
    
    public int setDataProducto(Producto producto){
        String sql = "INSERT INTO Tbl_Producto (Pro_Id, Pro_Nombre, Pro_Valor, Pro_Descripcion) VALUES (?,?,?,?);";
        this.db.query(sql);
        this.db.statementString(1, producto.getId());
        this.db.statementString(2, producto.getNombre());
        this.db.statementInt(3, producto.getValor());
        this.db.statementString(4, producto.getDescripcion());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }else
            this.db.rolback();
        return 0;
    }
    
    public int setUpdateProducto(Producto producto){
        String sql = "UPDATE Tbl_Producto SET Pro_Nombre = ?, Pro_Valor = ?, Pro_Descripcion = ? WHERE Pro_Id = ?;";
        this.db.query(sql);
        this.db.statementString(1, producto.getNombre());
        this.db.statementInt(2, producto.getValor());
        this.db.statementString(3, producto.getDescripcion());
        this.db.statementString(4, producto.getId());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }else
            this.db.rolback();
        return 0;
    }
    
    public int setDeleteProducto(Producto producto){
        String sql = "DELETE FROM Tbl_Producto WHERE Pro_Id = ?";
        this.db.query(sql);
        this.db.statementString(1, producto.getId());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }else
            this.db.rolback();
        return 0;
    }
    
    public ArrayList<Producto> getDataProducto(){
        ArrayList<Producto> productoArray = new ArrayList<>();
        String sql = "SELECT * FROM Tbl_Producto";
        this.db.query(sql);
        ResultSet rs = this.db.execute();
        try{
            while(rs != null && rs.next()){
                productoArray.add(new Producto(rs.getString("Pro_Nombre"),rs.getString("Pro_Descripcion"),rs.getInt("Pro_Valor"),rs.getString("Pro_Id")));
            }
        }catch(SQLException e){}
        return productoArray;
    }
    
    public boolean getDataProductoKey(Producto producto){
        String sql = "SELECT * FROM Tbl_Producto WHERE Pro_Id = ?";
        this.db.query(sql);
        this.db.statementString(1, producto.getId());
        ResultSet rs = this.db.execute();
        try{
            if(rs.next()){
                producto.setId(rs.getString(1));
                producto.setNombre(rs.getString(2));
                producto.setValor(rs.getInt(3));
                producto.setDescripcion(rs.getString(4));
                return true;
            }
        }catch(SQLException e){System.out.println(e);}
        return false;
    }
}
