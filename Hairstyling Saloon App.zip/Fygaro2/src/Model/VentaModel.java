/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Params.Ventas;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author carlos_sanchez
 */
public class VentaModel {
    
    private final Mysql db;

    public VentaModel(){
        this.db = new Mysql();
    }
    
    public int setDataVenta(Ventas venta){
        String sql = "INSERT INTO Tbl_Ventas (Ven_Id, Ven_Valor, Ven_Cantidad, Ven_Fecha, Ven_Descripcion, Tbl_Empleado_Emp_Documento, Tbl_Cliente_Cli_Id, Tbl_Producto_Pro_Id, Tbl_Caja_Caj_Id) VALUES (?,?,?,?,?,?,?,?,?);";
        this.db.query(sql);
        this.db.statementInt(1, venta.getId());
        this.db.statementInt(2, venta.getValor());
        this.db.statementInt(3, venta.getCantidad());
        this.db.statementString(4, venta.getFecha());
        this.db.statementString(5, venta.getDescripcion());
        this.db.statementInt(6, venta.getEmpleado());
        this.db.statementInt(7, venta.getCliente());
        this.db.statementInt(8, venta.getProducto());
        this.db.statementInt(9, venta.getCaja());
        if(this.db.executeUpdate() == 1){
            this.db.commit();
            return 1;
        }else
            this.db.rolback();
        return 0;
    }
    
    public boolean getDataVentaKey(Ventas venta){
        String sql = "SELECT * FROM Tbl_Ventas WHERE Ven_Id = ?;";
        this.db.query(sql);
        this.db.statementInt(1, venta.getId());
        ResultSet rs = this.db.execute();
        try{
            if(rs != null && rs.next()){
                venta.setValor(rs.getInt("Ven_Valor"));
                venta.setCantidad(rs.getInt("Ven_Cantidad"));
                venta.setFecha(rs.getString("Ven_Fecha"));
                venta.setDescripcion(rs.getString("Ven_Descripcion"));
                venta.setEmpleado(rs.getInt("Tbl_Empleado_Emp_Documento"));
                venta.setCliente(rs.getInt("Tbl_Cliente_Cli_Id"));
                venta.setProducto(rs.getInt("Tbl_Producto_Pro_Id"));
                venta.setCaja(rs.getInt("Tbl_Caja_Caj_Id"));
                return true;
            }
        }catch(SQLException e){}
        return false;
    }
    
    public ArrayList<Ventas> getAllDataVenta(){
        ArrayList<Ventas> ventaArray = new ArrayList<>();
        String sql = "SELECT venta.*, producto.Pro_Nombre, empleado.Emp_Nombre," +
        "empleado.Emp_Apellido, cliente.Cli_Nombre, cliente.Cli_Apellido FROM Bd_Peluqueria.Tbl_Ventas AS venta " +
        "INNER JOIN Bd_Peluqueria.Tbl_Producto AS producto ON producto.Pro_Id = venta.Tbl_Producto_Pro_Id " +
        "INNER JOIN Bd_Peluqueria.Tbl_Empleado AS empleado ON empleado.Emp_Documento = venta.Tbl_Empleado_Emp_Documento " +
        "INNER JOIN Bd_Peluqueria.Tbl_Cliente AS cliente ON cliente.Cli_Id = venta.Tbl_Cliente_Cli_Id;";
        this.db.query(sql);
        ResultSet rs = this.db.execute();
        try{
            while(rs != null && rs.next()){
                ventaArray.add(new Ventas(rs.getInt("Ven_Id"), rs.getInt("Ven_Cantidad"), rs.getInt("Ven_Valor"), rs.getString("Ven_Fecha"), rs.getString("Ven_Descripcion"), rs.getString("Emp_Nombre") + " " + rs.getString("Emp_Apellido"), rs.getString("Cli_Nombre") + " " + rs.getString("Cli_Apellido"), rs.getString("Pro_Nombre"), rs.getInt("Tbl_Caja_Caj_Id")));
            }
        }catch(SQLException e){
            System.out.println(e);
        }
        return ventaArray;
    }
    
    public ArrayList<Ventas> getAllDataKey(Ventas venta){
        ArrayList<Ventas> ventaArray = new ArrayList<>();
        String sql = "SELECT " +
            "    venta.*, " +
            "    caja.Caj_Capital, " +
            "    producto.Pro_Nombre, " +
            "    empleado.Emp_Nombre, " +
            "    empleado.Emp_Apellido, " +
            "    cliente.Cli_Nombre, " +
            "    cliente.Cli_Apellido " +
            " FROM " +
            "    Tbl_Ventas AS venta " +
            "        INNER JOIN " +
            "    Tbl_Producto AS producto ON producto.Pro_Id = venta.Tbl_Producto_Pro_Id " +
            "        INNER JOIN " +
            "    Tbl_Empleado AS empleado ON empleado.Emp_Documento = venta.Tbl_Empleado_Emp_Documento " +
            "        INNER JOIN " +
            "    Tbl_Cliente AS cliente ON cliente.Cli_Id = venta.Tbl_Cliente_Cli_Id " +
            "        INNER JOIN " +
            "    Tbl_Caja AS caja ON caja.Caj_Id = venta.Tbl_Caja_Caj_Id " +
            " WHERE " +
            "    venta.Ven_Fecha LIKE ?;";
        this.db.query(sql);
        this.db.statementString(1, venta.getFecha());
        ResultSet rs = this.db.execute();
        try{
            while(rs != null && rs.next()){
                ventaArray.add(new Ventas(rs.getInt("Ven_Id"), rs.getInt("Ven_Cantidad"), rs.getInt("Ven_Valor"), rs.getString("Ven_Fecha"), rs.getString("Ven_Descripcion"), rs.getString("Emp_Nombre") + " " + rs.getString("Emp_Apellido"), rs.getString("Cli_Nombre") + " " + rs.getString("Cli_Apellido"), rs.getString("Pro_Nombre"), rs.getInt("Tbl_Caja_Caj_Id")));
            }
        }catch(SQLException e){
            System.out.println(e);
        }
        return ventaArray;
    }
}
