/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Params;

/**
 *
 * @author carlos_sanchez
 */
public class Caja {
    public int Id;
    public int Capital;

    public Caja(int Id, int Capital) {
        this.Id = Id;
        this.Capital = Capital;
    }
    
    public Caja(){}
    
    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getCapital() {
        return Capital;
    }

    public void setCapital(int Capital) {
        this.Capital = Capital;
    }
    
}
