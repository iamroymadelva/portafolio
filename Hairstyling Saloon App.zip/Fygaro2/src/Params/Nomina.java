/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Params;

/**
 *
 * @author carlos_sanchez
 */
public class Nomina {
    public int Id;
    public String Fecha;
    public String Fecha_Inicio;
    public String Fecha_Final;
    public int Caja;
    public double Porcentaje;
    public double Valor_Est;
    public int Documento_Empleado;

    public Nomina(int Id, String Fecha, String Fecha_Inicio, String Fecha_Final, int Caja, double Porcentaje, double Valor_Est, int Documento_Empleado) {
        this.Id = Id;
        this.Fecha = Fecha;
        this.Fecha_Inicio = Fecha_Inicio;
        this.Fecha_Final = Fecha_Final;
        this.Caja = Caja;
        this.Porcentaje = Porcentaje;
        this.Valor_Est = Valor_Est;
        this.Documento_Empleado = Documento_Empleado;
    }

    public Nomina(){}
    
    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public String getFecha_Inicio() {
        return Fecha_Inicio;
    }

    public void setFecha_Inicio(String Fecha_Inicio) {
        this.Fecha_Inicio = Fecha_Inicio;
    }

    public String getFecha_Final() {
        return Fecha_Final;
    }

    public void setFecha_Final(String Fecha_Final) {
        this.Fecha_Final = Fecha_Final;
    }

    public int getCaja() {
        return Caja;
    }

    public void setCaja(int Caja) {
        this.Caja = Caja;
    }

    public double getPorcentaje() {
        return Porcentaje;
    }

    public void setPorcentaje(double Porcentaje) {
        this.Porcentaje = Porcentaje;
    }

    public double getValor_Est() {
        return Valor_Est;
    }

    public void setValor_Est(double Valor_Est) {
        this.Valor_Est = Valor_Est;
    }

    public int getDocumento_Empleado() {
        return Documento_Empleado;
    }

    public void setDocumento_Empleado(int Documento_Empleado) {
        this.Documento_Empleado = Documento_Empleado;
    }
    
}
