/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Params;

/**
 *
 * @author carlos_sanchez
 */
public class Producto {
    
    public String Nombre;
    public String Descripcion;
    public int Valor;
    public String Id;

    public Producto(String Nombre, String Descripcion, int Valor, String Id) {
        this.Nombre = Nombre;
        this.Descripcion = Descripcion;
        this.Valor = Valor;
        this.Id = Id;
    }
    
    public Producto(){}
    
    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public int getValor() {
        return Valor;
    }

    public void setValor(int Valor) {
        this.Valor = Valor;
    }

}
