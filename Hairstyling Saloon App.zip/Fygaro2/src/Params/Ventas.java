/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Params;

/**
 *
 * @author carlos_sanchez
 */
public class Ventas {
    
    public int Id;
    public int Cantidad;
    public int Valor;
    public String Fecha;
    public String Descripcion;
    public int Empleado;
    public int Cliente = 0;
    public int Producto;
    public int Caja;
    public String OtherEmpleado;
    public String OtherCliente;
    public String OtherProducto;
    public String OtherCaja;

    public Ventas(int Id, int Cantidad, int Valor, String Fecha, String Descripcion, int Empleado, int Cliente, int Producto, int Caja) {
        this.Id = Id;
        this.Cantidad = Cantidad;
        this.Valor = Valor;
        this.Fecha = Fecha;
        this.Descripcion = Descripcion;
        this.Empleado = Empleado;
        this.Cliente = Cliente;
        this.Producto = Producto;
        this.Caja = Caja;
    }

    public Ventas(int Id, int Cantidad, int Valor, String Fecha, String Descripcion, String OtherEmpleado, String OtherCliente, String OtherProducto, int Caja) {
        this.Id = Id;
        this.Cantidad = Cantidad;
        this.Valor = Valor;
        this.Fecha = Fecha;
        this.Caja = Caja;
        this.Descripcion = Descripcion;
        this.OtherEmpleado = OtherEmpleado;
        this.OtherCliente = OtherCliente;
        this.OtherProducto = OtherProducto;
    }
    
    public Ventas(){}

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public int getValor() {
        return Valor;
    }

    public void setValor(int Valor) {
        this.Valor = Valor;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public int getEmpleado() {
        return Empleado;
    }

    public void setEmpleado(int Empleado) {
        this.Empleado = Empleado;
    }

    public int getCliente() {
        return Cliente;
    }

    public void setCliente(int Cliente) {
        this.Cliente = Cliente;
    }

    public int getProducto() {
        return Producto;
    }

    public void setProducto(int Producto) {
        this.Producto = Producto;
    }

    public int getCaja() {
        return Caja;
    }

    public void setCaja(int Caja) {
        this.Caja = Caja;
    }

    public String getOtherEmpleado() {
        return OtherEmpleado;
    }

    public void setOtherEmpleado(String OtherEmpleado) {
        this.OtherEmpleado = OtherEmpleado;
    }

    public String getOtherCliente() {
        return OtherCliente;
    }

    public void setOtherCliente(String OtherCliente) {
        this.OtherCliente = OtherCliente;
    }

    public String getOtherProducto() {
        return OtherProducto;
    }

    public void setOtherProducto(String OtherProducto) {
        this.OtherProducto = OtherProducto;
    }

    public String getOtherCaja() {
        return OtherCaja;
    }

    public void setOtherCaja(String OtherCaja) {
        this.OtherCaja = OtherCaja;
    }
    
    
    
}
